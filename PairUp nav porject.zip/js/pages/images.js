(function() {
  const filterButtons = document.querySelectorAll('.filter-btn');
  const galleryItems = document.querySelectorAll('.gallery-item');
  const gallerySearch = document.getElementById('gallerySearch');
  if (!filterButtons.length || !galleryItems.length) return;
  
  filterButtons.forEach(button => {
    button.addEventListener('click', () => {
      filterButtons.forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');
      filterGalleryItems(button.dataset.filter);
    });
  });
  
  gallerySearch?.addEventListener('input', () => {
    const term = gallerySearch.value.toLowerCase();
    const activeFilter = document.querySelector('.filter-btn.active')?.dataset.filter || 'all';
    filterGalleryItems(activeFilter, term);
  });
  
  function filterGalleryItems(filterValue, searchTerm = '') {
    galleryItems.forEach(item => {
      const matchesFilter = filterValue === 'all' || item.dataset.category === filterValue;
      const matchesSearch = item.querySelector('h3')?.textContent.toLowerCase().includes(searchTerm);
      item.style.display = (matchesFilter && matchesSearch) ? 'block' : 'none';
    });
  }
  
  document.querySelectorAll('.video-thumbnail').forEach(thumb => {
    thumb.addEventListener('click', () => alert('Video player would open here in a full implementation'));
  });
  
  document.querySelector('.load-btn')?.addEventListener('click', () => {
    alert('More items would be loaded here in a full implementation');
  });
})();