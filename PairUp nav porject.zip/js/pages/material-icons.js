(function() {
  const materialIcons = [
    { name: "home", category: "home" },
    { name: "search", category: "action" },
    { name: "account_circle", category: "action" },
    { name: "settings", category: "action" },
    { name: "done", category: "action" },
    { name: "info", category: "alert" },
    { name: "warning", category: "alert" },
    { name: "play_arrow", category: "av" },
    { name: "pause", category: "av" },
    { name: "chat", category: "communication" },
    { name: "email", category: "communication" },
    { name: "file_copy", category: "file" },
    { name: "folder", category: "file" },
    { name: "camera", category: "image" },
    { name: "map", category: "maps" },
    { name: "directions", category: "navigation" },
    { name: "notifications", category: "notification" },
    { name: "share", category: "social" },
    { name: "house", category: "home" },
    { name: "business", category: "home" },
    { name: "store", category: "home" },
    { name: "local_mall", category: "home" },
    { name: "shopping_basket", category: "home" },
    { name: "storefront", category: "home" },
    { name: "edit", category: "action" },
    { name: "delete", category: "action" },
    { name: "add", category: "action" },
    { name: "remove", category: "action" },
    { name: "favorite", category: "action" },
    { name: "visibility", category: "action" },
    { name: "visibility_off", category: "action" },
    { name: "lock", category: "action" },
    { name: "lock_open", category: "action" },
    { name: "star", category: "action" },
    { name: "star_border", category: "action" },
    { name: "thumb_up", category: "action" },
    { name: "thumb_down", category: "action" },
    { name: "error", category: "alert" },
    { name: "notification_important", category: "alert" },
    { name: "report_problem", category: "alert" },
    { name: "dangerous", category: "alert" },
    { name: "error_outline", category: "alert" },
    { name: "warning_amber", category: "alert" },
    { name: "stop", category: "av" },
    { name: "volume_up", category: "av" },
    { name: "volume_off", category: "av" },
    { name: "skip_next", category: "av" },
    { name: "skip_previous", category: "av" },
    { name: "playlist_play", category: "av" },
    { name: "music_note", category: "av" },
    { name: "audiotrack", category: "av" },
    { name: "video_library", category: "av" },
    { name: "movie", category: "av" },
    { name: "phone", category: "communication" },
    { name: "message", category: "communication" },
    { name: "forum", category: "communication" },
    { name: "contact_mail", category: "communication" },
    { name: "contact_phone", category: "communication" },
    { name: "sms", category: "communication" },
    { name: "cloud", category: "file" },
    { name: "attach_file", category: "file" },
    { name: "cloud_upload", category: "file" },
    { name: "cloud_download", category: "file" },
    { name: "file_download", category: "file" },
    { name: "file_upload", category: "file" },
    { name: "file_present", category: "file" },
    { name: "computer", category: "device" },
    { name: "tablet", category: "device" },
    { name: "smartphone", category: "device" },
    { name: "watch", category: "device" },
    { name: "format_bold", category: "editor" },
    { name: "format_italic", category: "editor" },
    { name: "format_underlined", category: "editor" },
    { name: "format_list_bulleted", category: "editor" },
    { name: "folder_open", category: "file" },
    { name: "keyboard", category: "hardware" },
    { name: "mouse", category: "hardware" },
    { name: "printer", category: "hardware" },
    { name: "image", category: "image" },
    { name: "photo", category: "image" },
    { name: "place", category: "maps" },
    { name: "my_location", category: "navigation" },
    { name: "alarm", category: "notification" },
    { name: "group", category: "social" },
    { name: "people", category: "social" },
    { name: "public", category: "social" },
    { name: "school", category: "social" },
    { name: "work", category: "social" },
    { name: "shopping_cart", category: "social" },
    { name: "local_grocery_store", category: "social" },
    { name: "local_offer", category: "social" },
    { name: "local_hospital", category: "social" },
    { name: "local_cafe", category: "social" },
    { name: "local_bar", category: "social" },
    { name: "local_library", category: "social" },
    { name: "local_pharmacy", category: "social" },
    { name: "local_post_office", category: "social" },
    { name: "local_shipping", category: "social" },
    { name: "local_taxi", category: "social" },
    { name: "local_fire_department", category: "social" },
    { name: "local_parking", category: "social" },
    { name: "local_atm", category: "social" },
    { name: "wifi", category: "network" },
    { name: "wifi_off", category: "network" },
    { name: "signal_cellular_4_bar", category: "network" },
    { name: "router", category: "network" },
    { name: "lan", category: "network" },
    { name: "cloud_queue", category: "network" },
    { name: "cloud_done", category: "network" },
    { name: "cloud_off", category: "network" },
    { name: "cloud_sync", category: "network" },
    { name: "security", category: "security" },
    { name: "vpn_key", category: "security" },
    { name: "verified_user", category: "security" }
  ];
  
  const iconsGrid = document.getElementById('iconsGrid');
  if (!iconsGrid) return;
  
  function renderIcons(icons) {
    iconsGrid.innerHTML = '';
    icons.forEach(icon => {
      const card = document.createElement('div');
      card.className = 'icon-card';
      card.innerHTML = `<i class="material-icons">${icon.name}</i><span>${icon.name}</span>`;
      card.addEventListener('click', () => showIconDetail(icon));
      iconsGrid.appendChild(card);
    });
  }
  
  function showIconDetail(icon) {
    document.getElementById('modalIcon').textContent = icon.name;
    document.getElementById('iconName').textContent = icon.name;
    document.getElementById('iconHtml').textContent = `<i class="material-icons">${icon.name}</i>`;
    document.getElementById('iconCss').textContent = `.material-icons { font-family: 'Material Icons'; content: '${icon.name}'; }`;
    document.getElementById('iconDetailModal').style.display = 'flex';
  }
  
  function filterIcons() {
    const searchValue = document.getElementById('iconSearch').value.toLowerCase();
    const categoryValue = document.getElementById('categoryFilter').value;
    const filtered = materialIcons.filter(icon =>
      icon.name.toLowerCase().includes(searchValue) &&
      (categoryValue === 'all' || icon.category === categoryValue)
    );
    renderIcons(filtered);
  }
  
  document.getElementById('iconSearch').addEventListener('input', filterIcons);
  document.getElementById('categoryFilter').addEventListener('change', filterIcons);
  document.getElementById('clearSearch').addEventListener('click', () => {
    document.getElementById('iconSearch').value = '';
    filterIcons();
  });
  document.querySelector('.close-modal').addEventListener('click', () => {
    document.getElementById('iconDetailModal').style.display = 'none';
  });
  document.getElementById('copyHtml').addEventListener('click', () => {
    navigator.clipboard.writeText(document.getElementById('iconHtml').textContent);
    alert('HTML copied to clipboard!');
  });
  document.getElementById('copyCss').addEventListener('click', () => {
    navigator.clipboard.writeText(document.getElementById('iconCss').textContent);
    alert('CSS copied to clipboard!');
  });
  
  renderIcons(materialIcons);
})();