(function() {
  function initCalendar() {
    const calendarGrid = document.querySelector('#widgets-page .calendar-grid');
    if (!calendarGrid) return;
    const daysInMonth = 30;
    const startingDay = 3;
    
    calendarGrid.innerHTML = '';
    for (let i = 0; i < startingDay; i++) {
      const empty = document.createElement('div');
      empty.className = 'calendar-day empty';
      calendarGrid.appendChild(empty);
    }
    for (let day = 1; day <= daysInMonth; day++) {
      const cell = document.createElement('div');
      cell.className = 'calendar-day';
      cell.textContent = day;
      if (day === new Date().getDate()) cell.classList.add('active');
      calendarGrid.appendChild(cell);
    }
  }
  
  function initProgressCircle() {
    const circle = document.querySelector('#widgets-page .progress-ring-circle');
    if (!circle) return;
    const radius = circle.r.baseVal.value;
    const circumference = 2 * Math.PI * radius;
    const progressValue = document.querySelector('.progress-circle')?.dataset.value || 0;
    
    circle.style.strokeDasharray = `${circumference} ${circumference}`;
    circle.style.strokeDashoffset = circumference;
    const offset = circumference - (progressValue / 100) * circumference;
    circle.style.strokeDashoffset = offset;
    circle.style.stroke = '#1d4ed8';
  }
  
  function filterWidgets() {
    const categoryBtns = document.querySelectorAll('#widgets-page .category-btn');
    categoryBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        categoryBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const category = btn.dataset.category;
        document.querySelectorAll('#widgets-page .widget-card').forEach(widget => {
          widget.style.display =
            (category === 'all' || widget.dataset.category === category) ? 'block' : 'none';
        });
      });
    });
  }
  
  document.addEventListener('DOMContentLoaded', () => {
    initCalendar();
    initProgressCircle();
    filterWidgets();
  });
})();


