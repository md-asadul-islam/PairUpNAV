(function() {
  const viewAllBtn = document.getElementById('viewAllUsers');
  viewAllBtn?.addEventListener('click', () => {
    alert('Loading all users...');
  });
  
  document.querySelectorAll('#user-page .message-btn').forEach(button => {
    button.addEventListener('click', function() {
      const row = this.closest('.table-row');
      const name = row?.querySelector('.table-cell:nth-child(3)')?.textContent || 'user';
      alert(`Opening message interface for ${name}`);
    });
  });
  
  document.querySelector('#user-page .edit-btn')?.addEventListener('click', () => {
    alert('Opening profile editor...');
  });
})();


