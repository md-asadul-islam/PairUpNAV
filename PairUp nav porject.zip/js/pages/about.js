(function() {
  function animateCounters() {
    const counters = document.querySelectorAll('#about-page .stat-number');
    const speed = 200;
    
    counters.forEach(counter => {
      const target = +counter.getAttribute('data-count');
      let count = +counter.innerText;
      const increment = target / speed;
      
      const tick = () => {
        if (count < target) {
          count += increment;
          counter.innerText = Math.ceil(count);
          requestAnimationFrame(tick);
        } else {
          counter.innerText = target;
        }
      };
      tick();
    });
  }
  
  document.querySelector('.menu-item[data-page="about-page"]')
    ?.addEventListener('click', () => setTimeout(animateCounters, 300));
})();