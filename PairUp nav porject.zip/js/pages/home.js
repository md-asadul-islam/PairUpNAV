(function() {
  // Any Home page specific interactions
  const video = document.getElementById('heroVideo');
  if (video) {
    video.addEventListener('error', () => {
      console.warn('Hero video failed to load.');
    });
  }
})();



