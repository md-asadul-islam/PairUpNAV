(function () {
  const contactForm = document.getElementById('contactForm');
  if (!contactForm) return;

  const nameInput = document.getElementById('name');
  const emailInput = document.getElementById('email');
  const subjectInput = document.getElementById('subject');
  const messageInput = document.getElementById('message');

  contactForm.addEventListener('submit', (e) => {
    e.preventDefault();
    let isValid = true;

    if (!nameInput.value.trim()) { showError(nameInput, 'Name is required'); isValid = false; } else clearError(nameInput);
    if (!emailInput.value.trim()) { showError(emailInput, 'Email is required'); isValid = false; }
    else if (!isValidEmail(emailInput.value.trim())) { showError(emailInput, 'Please enter a valid email'); isValid = false; }
    else clearError(emailInput);
    if (!subjectInput.value.trim()) { showError(subjectInput, 'Subject is required'); isValid = false; } else clearError(subjectInput);
    if (!messageInput.value.trim()) { showError(messageInput, 'Message is required'); isValid = false; } else clearError(messageInput);

    if (isValid) {
      alert('Message sent successfully!');
      contactForm.reset();
    }
  });

  function showError(input, message) {
    const group = input.parentElement;
    const err = group.querySelector('.error-message');
    input.style.borderColor = '#ef4444';
    err.textContent = message;
    err.style.display = 'block';
  }
  function clearError(input) {
    const group = input.parentElement;
    const err = group.querySelector('.error-message');
    input.style.borderColor = '#ddd';
    err.textContent = '';
    err.style.display = 'none';
  }
  function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  /* Floating quick-contact button */
  const floatingBtn = document.getElementById('floatingContactBtn');
  const contactPage = document.getElementById('contact-page');
  const contactFormSection = document.querySelector('.contact-form-section');

  floatingBtn?.addEventListener('click', () => {
    if (!contactPage.classList.contains('active')) {
      document.querySelector('.page-content.active')?.classList.remove('active');
      contactPage.classList.add('active');
      const menuItems = document.querySelectorAll('.menu-item');
      menuItems.forEach(i => i.classList.remove('active'));
      const target = document.querySelector('.menu-item[data-page="contact-page"]');
      if (target) {
        target.classList.add('active');
        const idx = Array.from(menuItems).indexOf(target);
        window.PairUpSidebar?.updateBlobs(idx);
      }
    }

    setTimeout(() => {
      contactFormSection?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      document.querySelectorAll('.form-group').forEach(group => {
        group.style.transition = 'all 0.3s ease';
        group.style.boxShadow = '0 0 0 2px rgba(59, 130, 246, 0.3)';
        group.style.borderRadius = '8px';
        group.style.padding = '0.5rem';
        setTimeout(() => {
          group.style.boxShadow = 'none';
          group.style.padding = '0';
        }, 3000);
      });
      const firstInput = contactFormSection?.querySelector('input, textarea');
      setTimeout(() => firstInput?.focus({ preventScroll: true }), 1000);
    }, 100);
  });
})();


