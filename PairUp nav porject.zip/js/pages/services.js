(function() {
  let currentTestimonial = 0;
  const testimonials = document.querySelectorAll('#services-page .testimonial');
  if (!testimonials.length) return;
  
  function showTestimonial(index) {
    testimonials.forEach((t, i) => (t.style.display = i === index ? 'block' : 'none'));
  }
  
  setInterval(() => {
    currentTestimonial = (currentTestimonial + 1) % testimonials.length;
    showTestimonial(currentTestimonial);
  }, 5000);
  
  showTestimonial(0);
})();