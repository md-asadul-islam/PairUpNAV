(function() {
  const conversations = document.querySelectorAll('.conversation');
  
  conversations.forEach(conversation => {
    conversation.addEventListener('click', function() {
      conversations.forEach(c => c.classList.remove('active'));
      this.classList.add('active');
      const userName = this.querySelector('.conversation-name')?.textContent;
      console.log(`Loading conversation with ${userName}`);
    });
  });
  
  document.querySelector('.new-message-btn')?.addEventListener('click', () => {
    alert('Opening new message dialog...');
  });
  
  const messageInput = document.querySelector('.message-composer input');
  const sendBtn = document.querySelector('.send-btn');
  
  function sendMessage() {
    const text = messageInput?.value.trim();
    if (!text) return;
    const messagesList = document.querySelector('.messages-list');
    const newMessage = document.createElement('div');
    newMessage.className = 'message outgoing';
    newMessage.innerHTML = `
      <div class="message-content">
        <p>${text}</p>
        <span class="message-time">${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
      </div>`;
    messagesList?.appendChild(newMessage);
    messageInput.value = '';
    if (messagesList) messagesList.scrollTop = messagesList.scrollHeight;
  }
  
  sendBtn?.addEventListener('click', sendMessage);
  messageInput?.addEventListener('keypress', e => { if (e.key === 'Enter') sendMessage(); });
  document.querySelector('.composer-action-btn')?.addEventListener('click', () => alert('Opening file picker...'));
  
  const messagesList = document.querySelector('.messages-list');
  if (messagesList) messagesList.scrollTop = messagesList.scrollHeight;
})();

/* Mobile chat overlay */
(function() {
  if (window.innerWidth > 768) return;
  
  const overlay = document.getElementById('mobileChatOverlay');
  const closeBtn = document.querySelector('.close-chat-btn');
  const conversations = document.querySelectorAll('.conversation');
  const floatingBtn = document.getElementById('floatingContactBtn');
  if (!overlay || !closeBtn || !conversations.length) return;
  
  closeBtn.addEventListener('click', () => {
    overlay.classList.remove('active');
    overlay.style.display = 'none';
    const sidebar = document.querySelector('.conversations-sidebar');
    if (sidebar) sidebar.style.display = 'flex';
    if (floatingBtn) floatingBtn.style.bottom = '20px';
  });
  
  conversations.forEach(conversation => {
    conversation.addEventListener('click', function() {
      const avatarImg = this.querySelector('img');
      const nameElem = this.querySelector('.conversation-name');
      if (!avatarImg || !nameElem) return;
      
      const avatar = avatarImg.cloneNode(true);
      const name = nameElem.textContent;
      const status = this.querySelector('.online-status') ? 'Online' : 'Offline';
      
      const partnerInfo = overlay.querySelector('.mobile-chat-partner');
      partnerInfo.innerHTML = '';
      const avatarContainer = document.createElement('div');
      avatarContainer.className = 'mobile-chat-avatar';
      avatarContainer.appendChild(avatar);
      partnerInfo.appendChild(avatarContainer);
      
      const textContainer = document.createElement('div');
      const nameEl = document.createElement('h3');
      nameEl.textContent = name;
      textContainer.appendChild(nameEl);
      const statusEl = document.createElement('p');
      statusEl.textContent = status;
      statusEl.className = 'status';
      textContainer.appendChild(statusEl);
      partnerInfo.appendChild(textContainer);
      
      const originalMessages = document.querySelector('.messages-list');
      if (!originalMessages) return;
      const messagesList = document.createElement('div');
      messagesList.className = 'messages-list';
      messagesList.innerHTML = originalMessages.innerHTML;
      const content = overlay.querySelector('.mobile-chat-content');
      content.innerHTML = '';
      content.appendChild(messagesList);
      
      const originalComposer = document.querySelector('.message-composer');
      const composer = originalComposer.cloneNode(true);
      const composerWrap = overlay.querySelector('.mobile-chat-composer');
      composerWrap.innerHTML = '';
      composerWrap.appendChild(composer);
      
      const mobileSendBtn = overlay.querySelector('.send-btn');
      const mobileInput = overlay.querySelector('.message-composer input');
      
      function sendMobile() {
        const text = mobileInput.value.trim();
        if (!text) return;
        const newMessage = document.createElement('div');
        newMessage.className = 'message outgoing';
        newMessage.innerHTML = `
          <div class="message-content">
            <p>${text}</p>
            <span class="message-time">${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          </div>`;
        messagesList.appendChild(newMessage);
        mobileInput.value = '';
        messagesList.scrollTop = messagesList.scrollHeight;
      }
      
      mobileSendBtn?.addEventListener('click', sendMobile);
      mobileInput?.addEventListener('keypress', e => { if (e.key === 'Enter') sendMobile(); });
      
      overlay.classList.add('active');
      overlay.style.display = 'flex';
      const sidebar = document.querySelector('.conversations-sidebar');
      if (sidebar) sidebar.style.display = 'none';
      if (floatingBtn) floatingBtn.style.bottom = '100px';
      
      messagesList.scrollTop = messagesList.scrollHeight;
    });
  });
})();

