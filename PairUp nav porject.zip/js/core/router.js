// Simple router — keeps existing "showPage" logic centralized.
// You can extend this to hash-based routing later:
//   window.location.hash = item.getAttribute('data-page');
(function() {
  // Nothing extra needed here right now; sidebar.js handles page switching.
  // Kept as a placeholder for future routing enhancements.
})();