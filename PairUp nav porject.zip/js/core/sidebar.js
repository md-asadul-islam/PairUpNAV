(function() {
  const menuToggle = document.getElementById('menuToggle');
  const toggleIcon = document.getElementById('toggleIcon');
  const menuItems = document.querySelectorAll('.menu-item');
  const topBlob = document.querySelector('.menu-blob.top');
  const bottomBlob = document.querySelector('.menu-blob.bottom');
  const body = document.body;
  const pageContents = document.querySelectorAll('.page-content');
  
  const itemHeight = 50;
  const topPadding = 120;
  
  function updateBlobs(index) {
    if (!topBlob || !bottomBlob) return;
    topBlob.style.height = `${itemHeight * index + topPadding}px`;
    bottomBlob.style.height = `calc(100% - ${(index + 1) * itemHeight + topPadding}px)`;
  }
  
  function showPage(pageId) {
    pageContents.forEach(c => c.classList.remove('active'));
    const target = document.getElementById(pageId);
    if (target) target.classList.add('active');
  }
  
  menuItems.forEach((item, index) => {
    item.addEventListener('click', () => {
      document.querySelector('.menu-item.active')?.classList.remove('active');
      item.classList.add('active');
      updateBlobs(index);
      showPage(item.getAttribute('data-page'));
    });
    
    if (item.classList.contains('active')) updateBlobs(index);
  });
  
  menuToggle?.addEventListener('click', () => {
    body.classList.toggle('menu-expanded');
    toggleIcon.textContent = body.classList.contains('menu-expanded') ? 'close' : 'menu';
  });
  
  // Expose for other scripts (e.g. floating button)
  window.PairUpSidebar = { showPage, updateBlobs, menuItems };
})();



