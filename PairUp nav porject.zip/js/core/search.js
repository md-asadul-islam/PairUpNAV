(function () {
  const container = document.querySelector('.top-search-container');
  const icon = document.querySelector('.top-search-icon');
  const input = document.querySelector('.top-search-input');
  const clearIcon = document.querySelector('.clear-search-icon');

  if (!container || !icon || !input) return;

  icon.addEventListener('click', (e) => {
    e.stopPropagation();
    if (!container.classList.contains('active')) {
      container.classList.add('active');
      input.focus();
    } else if (input.value.trim() !== '') {
      performSearch(input.value.trim());
    }
  });

  clearIcon?.addEventListener('click', (e) => {
    e.stopPropagation();
    input.value = '';
    input.focus();
    container.classList.remove('has-text');
    clearSearchResults();
  });

  input.addEventListener('input', (e) => {
    if (e.target.value.trim() !== '') container.classList.add('has-text');
    else container.classList.remove('has-text');
  });

  document.addEventListener('click', (e) => {
    if (!e.target.closest('.top-search-container')) {
      if (container.classList.contains('active')) {
        container.classList.remove('active', 'has-text');
        input.value = '';
        clearSearchResults();
      }
    }
  });

  function performSearch(query) { console.log('Searching for:', query); }
  function clearSearchResults() { console.log('Clearing search results'); }
})();



