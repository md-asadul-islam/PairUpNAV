// Global constants used across scripts
window.PAIRUP = {
  ITEM_HEIGHT: 50,
  TOP_PADDING: 120
};