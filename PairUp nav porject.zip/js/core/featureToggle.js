(function() {
  const featureToggle = document.getElementById('featureToggle');
  const featureToggleBtn = document.getElementById('featureToggleBtn');
  if (!featureToggle || !featureToggleBtn) return;
  
  featureToggleBtn.addEventListener('click', () => {
    featureToggle.classList.toggle('open');
  });
  
  document.addEventListener('click', (e) => {
    if (!featureToggle.contains(e.target)) featureToggle.classList.remove('open');
  });
})();