pairup/
├── index.html
├── css/
│   ├── core/
│   │   ├── variables.css
│   │   ├── base.css
│   │   ├── sidebar.css
│   │   ├── topbar.css
│   │   └── utilities.css
│   ├── components/
│   │   ├── buttons.css
│   │   ├── cards.css
│   │   └── forms.css
│   └── pages/
│       ├── home.css
│       ├── about.css
│       ├── services.css
│       ├── contact.css
│       ├── user.css
│       ├── message.css
│       ├── material-icons.css
│       ├── images.css
│       └── widgets.css
├── js/
│   ├── core/
│   │   ├── router.js
│   │   ├── theme.js
│   │   ├── sidebar.js
│   │   ├── search.js
│   │   └── featureToggle.js
│   └── pages/
│       ├── home.js
│       ├── about.js
│       ├── services.js
│       ├── contact.js
│       ├── user.js
│       ├── message.js
│       ├── material-icons.js
│       ├── images.js
│       └── widgets.js
└── assets/
    └── images/
    
    
    